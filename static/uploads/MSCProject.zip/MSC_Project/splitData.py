#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jul 15 19:13:24 2021

@author: maryamhatami
"""

# Convolutional Neural Network darpa/kddcup99

import tensorflow as tf
from keras import backend as K
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

from sklearn.preprocessing import LabelEncoder,OneHotEncoder
import os

os.environ['KMP_DUPLICATE_LIB_OK']='True'
tf.__version__

# Importing the dataset
#-------------------------train dataset
dataset = pd.read_csv('KDDCUP_Probe.csv')
#dataset = dataset.sample(n = 100000)

X = dataset.iloc[:, 1:-1].values#col:46-2=44       ########## 0:-2

y = dataset.iloc[:, -1].values 

for i in range(0,len(y)):
    if y[i]==1:
        y[i] = 1
    else:
        y[i] = -1

# Splitting the dataset into the Training set and Test set

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.8, random_state = 0)
print(np.count_nonzero(y_train == 1))#which are attack or not attack in train
print(np.count_nonzero(y_train == -1))
print(np.count_nonzero(y_test == 1))#which are attack or not attack in train
print(np.count_nonzero(y_test == -1)) 

import scipy.io
scipy.io.savemat('trainCUP_Probe.mat', dict(x11 = X_train, y11 = y_train))
scipy.io.savemat('testCUP_Probe.mat', dict(x22 = X_test, y22 = y_test))