#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Jun  5 16:39:52 2021

@author: maryamhatami
"""

# Convolutional Neural Network darpa/kddcup99

import tensorflow as tf
from keras import backend as K
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.preprocessing import LabelEncoder,OneHotEncoder
import os

os.environ['KMP_DUPLICATE_LIB_OK']='True'
tf.__version__

# Part 1 - Data Preprocessing

# Importing the dataset
#-------------------------train dataset
dataset1 = pd.read_csv('UNSW-NB15_1.csv')
dataset1.columns = ['srcip', 'sport', 'dstip', 'dsport',	'proto',	'state',
                                                      'dur', 'sbytes',	'dbutes',	'sttl',	'dttl',	'sloss',
                                                      'oss',	'service',	'Sload',	'Dload',	'Spkts',	
                                                      'Dpkts',	'swin',	'dwin',	'stcpb',	'dtcpb'
                                                      ,	'smeansz',	'dmeansz',	'trans_depth',	'res_bdy_len'
                                                      ,'Sjit',	'Djit',	'Stime',	'Ltime',	'Sintpkt'
                                                      ,'Dintpkt',	'tcprtt',	'synack',	'ackdat',	'is_sm_ips_ports'
                                                      ,	'ct_state_ttl',	'ct_flw_http_mthd',	'is_ftp_login'
                                                      ,	'ct_ftp_cmd',	'ct_srv_src',	'ct_srv_dst',	'ct_dst_ltm'
                                                      ,'ct_src_ltm',	'ct_src_dport_ltm',	'ct_dst_sport_ltm'
                                                      ,	'ct_dst_src_ltm',	'attack_cat',	'Label']
dataset2 = pd.read_csv('UNSW-NB15_2.csv')
dataset2.columns = ['srcip', 'sport', 'dstip', 'dsport',	'proto',	'state',
                                                      'dur', 'sbytes',	'dbutes',	'sttl',	'dttl',	'sloss',
                                                      'oss',	'service',	'Sload',	'Dload',	'Spkts',	
                                                      'Dpkts',	'swin',	'dwin',	'stcpb',	'dtcpb'
                                                      ,	'smeansz',	'dmeansz',	'trans_depth',	'res_bdy_len'
                                                      ,'Sjit',	'Djit',	'Stime',	'Ltime',	'Sintpkt'
                                                      ,'Dintpkt',	'tcprtt',	'synack',	'ackdat',	'is_sm_ips_ports'
                                                      ,	'ct_state_ttl',	'ct_flw_http_mthd',	'is_ftp_login'
                                                      ,	'ct_ftp_cmd',	'ct_srv_src',	'ct_srv_dst',	'ct_dst_ltm'
                                                      ,'ct_src_ltm',	'ct_src_dport_ltm',	'ct_dst_sport_ltm'
                                                      ,	'ct_dst_src_ltm',	'attack_cat',	'Label']

dataset3 = pd.read_csv('UNSW-NB15_3.csv')
dataset3.columns = ['srcip', 'sport', 'dstip', 'dsport',	'proto',	'state',
                                                      'dur', 'sbytes',	'dbutes',	'sttl',	'dttl',	'sloss',
                                                      'oss',	'service',	'Sload',	'Dload',	'Spkts',	
                                                      'Dpkts',	'swin',	'dwin',	'stcpb',	'dtcpb'
                                                      ,	'smeansz',	'dmeansz',	'trans_depth',	'res_bdy_len'
                                                      ,'Sjit',	'Djit',	'Stime',	'Ltime',	'Sintpkt'
                                                      ,'Dintpkt',	'tcprtt',	'synack',	'ackdat',	'is_sm_ips_ports'
                                                      ,	'ct_state_ttl',	'ct_flw_http_mthd',	'is_ftp_login'
                                                      ,	'ct_ftp_cmd',	'ct_srv_src',	'ct_srv_dst',	'ct_dst_ltm'
                                                      ,'ct_src_ltm',	'ct_src_dport_ltm',	'ct_dst_sport_ltm'
                                                      ,	'ct_dst_src_ltm',	'attack_cat',	'Label']

dataset4 = pd.read_csv('UNSW-NB15_4.csv')
dataset4.columns = ['srcip', 'sport', 'dstip', 'dsport',	'proto',	'state',
                                                      'dur', 'sbytes',	'dbutes',	'sttl',	'dttl',	'sloss',
                                                      'oss',	'service',	'Sload',	'Dload',	'Spkts',	
                                                      'Dpkts',	'swin',	'dwin',	'stcpb',	'dtcpb'
                                                      ,	'smeansz',	'dmeansz',	'trans_depth',	'res_bdy_len'
                                                      ,'Sjit',	'Djit',	'Stime',	'Ltime',	'Sintpkt'
                                                      ,'Dintpkt',	'tcprtt',	'synack',	'ackdat',	'is_sm_ips_ports'
                                                      ,	'ct_state_ttl',	'ct_flw_http_mthd',	'is_ftp_login'
                                                      ,	'ct_ftp_cmd',	'ct_srv_src',	'ct_srv_dst',	'ct_dst_ltm'
                                                      ,'ct_src_ltm',	'ct_src_dport_ltm',	'ct_dst_sport_ltm'
                                                      ,	'ct_dst_src_ltm',	'attack_cat',	'Label']


dataset = pd.concat([dataset1, dataset2, dataset3, dataset4])

#dataset = dataset.drop(['state','Stime', 'Ltime'],axis=1)#col: 49 - 3 = 46  (6,29,30)

dataset = dataset.sample(n = 1000000)

dataset.to_csv('UNSW_NB15_TEMPLATE2.csv')