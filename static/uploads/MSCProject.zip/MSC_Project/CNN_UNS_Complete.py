#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jul 16 17:54:23 2021

@author: maryamhatami
"""

# Convolutional Neural Network darpa/kddcup99

import tensorflow as tf
from keras import backend as K
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.preprocessing import LabelEncoder,OneHotEncoder
import os

os.environ['KMP_DUPLICATE_LIB_OK']='True'
tf.__version__

# Part 1 - Data Preprocessing

# Importing the dataset
#-------------------------train dataset
dataset = pd.read_csv('UNSW_NB15_DoS.csv')

X = dataset.iloc[:, 1:-1].values#col:46-2=44       ########## 0:-2

y = dataset.iloc[:, -1].values 


# Splitting the dataset into the Training set and Test set

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.8, random_state = 0)


# for softmax multi-classification:

print(np.count_nonzero(y_train == 1))#which are attack or not attack in train
print(np.count_nonzero(y_train == 0))
print(np.count_nonzero(y_test == 1))#which are attack or not attack in train
print(np.count_nonzero(y_test == 0)) 
#--------------------------------------scale data
from sklearn.preprocessing import MinMaxScaler
sc = MinMaxScaler(feature_range = (0,1))
X_train = sc.fit_transform(X_train)
X_train = X_train.reshape(X_train.shape[0],1,47,1).astype( 'float32' )# convert to image format for cnn6*7
X_test = sc.fit_transform(X_test)
X_test = X_test.reshape(X_test.shape[0],1,47,1).astype( 'float32' )

from sklearn import preprocessing
lb = preprocessing.LabelBinarizer()
y_train = lb.fit_transform(y_train)
y_test = lb.fit_transform(y_test)  


model = tf.keras.models.Sequential()
K.common.image_dim_ordering()


model.add(tf.keras.layers.Conv2D(filters=32, kernel_size= (1,23), input_shape=[1,47,1],activation='relu'))
model.add(tf.keras.layers.MaxPool2D(pool_size= (1,2) , strides=1))
model.add(tf.keras.layers.Conv2D(filters=32, kernel_size= (1,23) , activation='relu'))#kernel_initializer = tf.keras.initializers.RandomUniform(minval=-0.05, maxval=0.05, seed=None)
model.add(tf.keras.layers.MaxPool2D(pool_size= (1,2), strides=1))

model.add(tf.keras.layers.Flatten())


# Step 5 - Output Layer

model.add(tf.keras.layers.Dense(units=1, activation='sigmoid'))

# Compile model

model.compile(optimizer = 'Adam' , loss = 'binary_crossentropy', 
              metrics=['accuracy', tf.keras.metrics.TrueNegatives(), tf.keras.metrics.TruePositives(), 
                       tf.keras.metrics.FalseNegatives(), tf.keras.metrics.FalsePositives(), tf.keras.metrics.AUC()])

# train

history = model.fit(X_train, y_train, batch_size=30, epochs=20 ,verbose=1,
          validation_data=(X_test, y_test))

# test

score = model.evaluate(X_test, y_test, batch_size=30, verbose = 2)
print("Accuracy: %.2f%%" % (score[1]*100))
print("Loss: %.2f%%" % (score[0]*100))
# TN, TP, FN, FP = 2,3,4,5
TN = score[2]
TP = score[3]
FN = score[4]
FP = score[5]
FPR = (FP / (FP + TN)) * 100
FNR = (FN / (FN + TP)) * 100
TPR = (TP / (TP + FN)) * 100
TNR = (TN / (TN + FP)) * 100
Precision =  (TP / (TP + FP)) * 100
F1_score = 2 * (Precision * TPR)/(Precision + TPR)
print("FPR: %.2f%%" % (FPR))
print("FNR: %.2f%%" % (FNR))
print("TPR: %.2f%%" % (TPR))
print("TNR: %.2f%%" % (TNR))
print("Precision: %.2f%%" % (Precision))
print("F1_score: %.2f%%" % (F1_score))

from sklearn.metrics import roc_curve, roc_auc_score
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
y_score1 = model.predict_proba(X_test)
false_positive_rate1, true_positive_rate1, threshold1 = roc_curve(y_test, y_score1)
print('roc_auc_score for cnn: ', roc_auc_score(y_test, y_score1))
plt.subplots(1, figsize=(10,10))
plt.title('Receiver Operating Characteristic - CNN')
plt.plot(false_positive_rate1, true_positive_rate1)
plt.plot([0, 1], ls="--")
plt.plot([0, 0], [1, 0] , c=".7"), plt.plot([1, 1] , c=".7")
plt.ylabel('True Positive Rate')
plt.xlabel('False Positive Rate')
plt.show()
#ROC
from sklearn.metrics import roc_curve
y_pred_keras = model.predict(X_test).ravel()
fpr_keras, tpr_keras, thresholds_keras = roc_curve(y_test, y_pred_keras)
#AUC
from sklearn.metrics import auc
auc_keras = auc(fpr_keras, tpr_keras)

plt.figure(1)
plt.figure(1).set_figwidth(5)
plt.figure(1).set_figheight(5)
plt.plot([0, 1], [0, 1], 'k--',lw=1)
plt.plot(fpr_keras, tpr_keras, label='(area = {:.3f})'.format(auc_keras),lw=1)
#plt.plot(fpr_rf, tpr_rf, label='RF (area = {:.3f})'.format(auc_rf))
plt.xlabel('False positive rate')
plt.ylabel('True positive rate')
plt.title('ROC curve', fontsize=10)
plt.legend(loc='best')
plt.show()
# Zoom in view of the upper left corner.
plt.figure(2)
plt.figure(2).set_figwidth(5)
plt.figure(2).set_figheight(5)
plt.xlim(0, 0.2)
plt.ylim(0.8, 1)
plt.plot([0, 1], [0, 1], 'k--',lw=1)
plt.plot(fpr_keras, tpr_keras, label='(area = {:.3f})'.format(auc_keras),lw=1)
#plt.plot(fpr_rf, tpr_rf, label='RF (area = {:.3f})'.format(auc_rf))
plt.xlabel('False positive rate')
plt.ylabel('True positive rate')
plt.title('ROC curve (zoomed in at top left)', fontsize=10)
plt.legend(loc='best')
plt.show()

#%matplotlib inline	
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
import seaborn as sns;
...
# list all data in history

print(history.history.keys())
accuracy = history.history['accuracy']
val_accuracy = history.history['val_accuracy']
loss = history.history['loss']
val_loss = history.history['val_loss']
epochs = range(len(accuracy))
#fig, ax = plt.subplots(figsize=(5, 3))

# Create bar plot
#ax.bar(epochs, accuracy)
plt.plot(epochs, val_accuracy, 'o-', label='Validation accuracy')
plt.plot(epochs, accuracy, 'o--', label='Training accuracy')
#plt.title('Training and validation accuracy')
plt.legend()
plt.figure()
plt.plot(epochs, val_loss, 'o-', label='Validation loss')
plt.plot(epochs, loss, 'o--', label='Training loss')
#plt.title('Training and validation loss')
plt.legend()
plt.show()
