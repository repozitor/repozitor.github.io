﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using System.Collections.Generic;
using UnityEngine.Analytics;

public class ButtonClick : MonoBehaviour {
	public GameObject Pnl_Win;
	public GameObject Pnl_GameOver;
	public List<Button> btnList;
	public  List<Image> platforms;
	//public List<Image> rabbits;
	public int countf=0;//count false letters
	public int countt=0;//count true letters
	string chosen="";//the letter, User has choosed
	string s= UIOfSectionChoose.gm.word.Replace (" ", string.Empty); 
	public Image answer;
	Vector3 platformPos;
    public GameObject PanelFadeInOut;
    Animator FadeInOut;
	// Use this for initialization
    public void Start()
    {
        FadeInOut = PanelFadeInOut.GetComponent<Animator>();
    }
	public void ButtonIsTrue0(){
		Recognization(btnList[0],btnList[0+33],btnList[0+33+33]);
	}
	public void ButtonIsTrue1(){
		Recognization(btnList[1],btnList[1+33],btnList[1+33+33]);
	}
	public void ButtonIsTrue2(){
		Recognization(btnList[2],btnList[2+33],btnList[2+33+33]);
	}
	public void ButtonIsTrue3(){
		Recognization(btnList[3],btnList[3+33],btnList[3+33+33]);
	}
	public void ButtonIsTrue4(){
		Recognization(btnList[4],btnList[4+33],btnList[4+33+33]);
	}
	public void ButtonIsTrue5(){
		Recognization(btnList[5],btnList[5+33],btnList[5+33+33]);
	}
	public void ButtonIsTrue6(){
		Recognization(btnList[6],btnList[6+33],btnList[6+33+33]);
	}
	public void ButtonIsTrue7(){
		Recognization(btnList[7],btnList[7+33],btnList[7+33+33]);
	}
	public void ButtonIsTrue8(){
		Recognization(btnList[8],btnList[8+33],btnList[8+33+33]);
	}
	public void ButtonIsTrue9(){
		Recognization(btnList[9],btnList[9+33],btnList[9+33+33]);
	}
	public void ButtonIsTrue10(){
		Recognization(btnList[10],btnList[10+33],btnList[10+33+33]);
	}
	public void ButtonIsTrue11(){
		Recognization(btnList[11],btnList[11+33],btnList[11+33+33]);
	}
	public void ButtonIsTrue12(){
		Recognization(btnList[12],btnList[12+33],btnList[12+33+33]);
	}
	public void ButtonIsTrue13(){
		Recognization(btnList[13],btnList[13+33],btnList[13+33+33]);
	}
	public void ButtonIsTrue14(){
		Recognization(btnList[14],btnList[14+33],btnList[14+33+33]);
	}
	public void ButtonIsTrue15(){
		Recognization(btnList[15],btnList[15+33],btnList[15+33+33]);
	}
	public void ButtonIsTrue16(){
		Recognization(btnList[16],btnList[16+33],btnList[16+33+33]);
	}
	public void ButtonIsTrue17(){
		Recognization(btnList[17],btnList[17+33],btnList[17+33+33]);
	}
	public void ButtonIsTrue18(){
		Recognization(btnList[18],btnList[18+33],btnList[18+33+33]);
	}
	public void ButtonIsTrue19(){
		Recognization(btnList[19],btnList[19+33],btnList[19+33+33]);
	}
	public void ButtonIsTrue20(){
		Recognization(btnList[20],btnList[20+33],btnList[20+33+33]);
	}
	public void ButtonIsTrue21(){
		Recognization(btnList[21],btnList[21+33],btnList[21+33+33]);
	}
	public void ButtonIsTrue22(){
		Recognization(btnList[22],btnList[22+33],btnList[22+33+33]);
	}
	public void ButtonIsTrue23(){
		Recognization(btnList[23],btnList[23+33],btnList[23+33+33]);
	}
	public void ButtonIsTrue24(){
		Recognization(btnList[24],btnList[24+33],btnList[24+33+33]);
	}
	public void ButtonIsTrue25(){
		Recognization(btnList[25],btnList[25+33],btnList[25+33+33]);
	}
	public void ButtonIsTrue26(){
		Recognization(btnList[26],btnList[26+33],btnList[26+33+33]);
	}
	public void ButtonIsTrue27(){
		Recognization(btnList[27],btnList[27+33],btnList[27+33+33]);
	}
	public void ButtonIsTrue28(){
		Recognization(btnList[28],btnList[28+33],btnList[28+33+33]);
	}
	public void ButtonIsTrue29(){
		Recognization(btnList[29],btnList[29+33],btnList[29+33+33]);
	}
	public void ButtonIsTrue30(){
		Recognization(btnList[30],btnList[30+33],btnList[30+33+33]);
	}
	public void ButtonIsTrue31(){
		Recognization(btnList[31],btnList[31+33],btnList[31+33+33]);
	}
	public void ButtonIsTrue32(){
		Recognization(btnList[32],btnList[32+33],btnList[32+33+33]);
	}
	
	public  void Recognization(Button b1 , Button b2 , Button b3){
		bool correct=false;//correct letter chosen
		if (countf < s.Length)
			correct = false;
		int check = 0;//repeated words
		int k = s.Length-1;//we declare k to set the platforms not ignoring the even number of the platforms
		for(int i=0;i<s.Length;i++){
			Vector3 platformPos = new Vector3 (240+100*k-(s.Length*50) , 857+k ,0.0f);//the platformplaces
			Vector3 DestroyPlat = new Vector3(-1000,-1000,0.0f);
			chosen = b1.GetComponentInChildren<Text>().text.ToString();
			if (chosen == s[i].ToString()) {
				countt++;
				correct = true;
				check++;
				//*******************************int[] values = new int[UIOfSectionChoose.gm.keyBoard.Count];//values
				//UIOfSectionChoose.gm.keyBoard.Values.CopyTo(values, 0);
				//int[] keys = new int[UIOfSectionChoose.gm.keyBoard.Count];//keys
				//********************************UIOfSectionChoose.gm.keyBoard.Keys.CopyTo(keys, 0);
				if(check==1){
					/*for(int j=0;j<UIOfSectionChoose.gm.keyBoard.Count;j++)
					{
						if(values[j] == UIOfSectionChoose.gm.buttons[chosen[0]]){
							UIOfSectionChoose.gm.saveCorrectLetter(UIOfSectionChoose.gm.buttons[chosen[0]],keys[j]);
						}
					}*/
					
					b1.transform.localPosition=platformPos;
				}
				if(check==2){
					/*for(int j=0;j<UIOfSectionChoose.gm.keyBoard.Count;j++)
					{
						if(values[j] == UIOfSectionChoose.gm.buttons[chosen[0]]){
							UIOfSectionChoose.gm.saveCorrectLetter(UIOfSectionChoose.gm.buttons[chosen[0]]+33,keys[j]);
						}
					}*/
					b2.transform.localPosition=platformPos;//repeated
				}
				if(check==3){
					/*for(int j=0;j<UIOfSectionChoose.gm.keyBoard.Count;j++)
					{
						if(values[j] == UIOfSectionChoose.gm.buttons[chosen[0]]){
							UIOfSectionChoose.gm.saveCorrectLetter((UIOfSectionChoose.gm.buttons[chosen[0]]+33+33),keys[j]);
						}
					}*/
					b3.transform.localPosition=platformPos;//repeated again
				}
				platforms[k].transform.localPosition=DestroyPlat;
			}
			k--;//with decreasing the number i of the string the number of k of the platforms should be increased too!
		}
		check = 0;
		if(correct ==false){
            UIOfSectionChoose.gm.soundstate(SoundState.Scream);
			Vector3 DestroyButton = new Vector3(-1000,-1000,0.0f);
			b1.transform.localPosition=DestroyButton;
            FadeInOut.enabled = true;
            Destroy(UIOfSectionChoose.gm.rabbits[countf]);
			//rabbits[countf].transform.localPosition = DestroyButton;
            StartCoroutine(wait());
			countf++;
			if (countf >=  s.Length) {//loose
                Analytics.CustomEvent("gameOver", new Dictionary<string, object>
  {
    { "levelNum", "levelNum"+UIOfSectionChoose.gm.currentLevel },
    { "score", UIOfSectionChoose.gm.score },
    { "currentTimeLeft", "levelTime"+UIOfSectionChoose.gm.time }
  });
                Debug.Log(Analytics.CustomEvent("gameOver", new Dictionary<string, object>
  {
    { "levelNum", "levelNum"+UIOfSectionChoose.gm.currentLevel },
    { "totalScore", UIOfSectionChoose.gm.score },
    { "currentTimeLeft", "levelTime"+UIOfSectionChoose.gm.time }
  }));
				UIOfSectionChoose.gm.setStateLoose();
				Pnl_GameOver.SetActive(true);
				countf=0;
				countt=0;
			}
		}//counting the false buttons
		
		if (countt == (s.Length)) {//win

            UIOfSectionChoose.gm.checkActive(UIOfSectionChoose.gm.time); //setting score!!!
            if(UIOfSectionChoose.gm.nextLevelPermission() == true){
            UIOfSectionChoose.gm.setNextLevel();
            }
            else
            {
                UIOfSectionChoose.gm.goNextLevel();
            }
			//Debug.Log("Hey you won! levelnum IS: "+UIOfSectionChoose.gm.currentLevel);
			UIOfSectionChoose.gm.setStateWin();
			Pnl_Win.SetActive(true);
			//answer.transform.localPosition = new Vector3 (0 , 200 ,0.0f);
			countf=0;
			countt=0;
		}
	}
    IEnumerator wait()
    {
        yield return new WaitForSeconds(2f);
        FadeInOut.enabled = false;
    }
}