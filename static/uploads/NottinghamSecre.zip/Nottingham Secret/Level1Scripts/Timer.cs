﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
public class Timer : MonoBehaviour {
	
	public Text timerLabel;
	public GameObject help_pnl;
	public GameObject Pnl_GameOver;
	public GameObject  Pnl_Win;
	
	public void Awake() {

	}
	
	// Use this for initialization
    float timeLimit;
	
	void Start () {
        UIOfSectionChoose.gm.time = timeLimit;
        if(UIOfSectionChoose.gm.currentGameState == GameState.Game){
    timeLimit = UIOfSectionChoose.gm.profile.areaDictionary[UIOfSectionChoose.gm.currentArea].zoneDictionary[UIOfSectionChoose.gm.currentZone].levelDictionary[UIOfSectionChoose.gm.currentLevel].time;//10.0f; // 10 seconds.
   // Debug.Log("Time Has Been set" + timeLimit);
      }
		var seconds = timeLimit % 60;//Use the euclidean division for the seconds.
		var fraction = (timeLimit * 100) % 100;
		
		//update the label value
		timerLabel.text =  string.Format (" {0:00} : {1:00}", seconds, fraction);
	}
	// Update is called once per frame
	void Update () {
        UIOfSectionChoose.gm.time = timeLimit;
		// translate object for 10 seconds.
		if (timeLimit > 0 && UIOfSectionChoose.gm.currentGameState == GameState.Game) {//
			// Decrease timeLimit.
			timeLimit -= Time.deltaTime;
			// translate backward.
			var seconds = timeLimit % 60;//Use the euclidean division for the seconds.
			var fraction = (timeLimit * 100) % 100;
			
			//update the label value
			
			timerLabel.text = string.Format ("{0:00} : {1:00}", seconds, fraction);
			transform.Translate (Vector3.back * Time.deltaTime, Space.World);
		}
		 if (timeLimit <= 0 ){
			Pnl_GameOver.SetActive(true);
		}
	} 
}
