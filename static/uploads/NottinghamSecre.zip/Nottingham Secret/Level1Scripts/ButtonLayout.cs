﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;

public class ButtonLayout : MonoBehaviour {
	public List<Button> buttonList;
	public float pltfrmVerticalDis , pltfrmHorizontalDis;
	public  List<Image> platforms;
    public Image rabbit;
    public GameObject rabbitParent;
	public float btnVerticalDis , btnHorizontalDis;
	float topLeftX , topLeftY;
	public static string word;
	int random=0;//other letters
	int ran = 0;//main letters random
	int[] checkRandom;
	int[] buttonElement;//buttonList[i]-->the i number of main letters
	int[] mainRandomPlaces;
	int letter=0;//not Repeated letters in the word
	int[] mainPlaces;//the places on the keyboard which the main letters of the word will be set randomly
	int[] checkRan;//places of the main words
	Dictionary<int,int> correctLetters;
	Dictionary<int,int> wrongLetters;
	Dictionary<int,int> keyBoard;
	// Use this for initialization
	void Start () {
        UIOfSectionChoose.gm.rabbits.Clear();
		//DeactivationAll ();
		UIOfSectionChoose.gm.buttons = new Dictionary<char, int> ();
		checkRan = new int[20];//for checking the houses of the keyboard has been chosen
		checkRandom = new int[34];
		buttonElement = new int[34];
		mainRandomPlaces = new int[34];
		for (int i = 0; i < 34; i++) {
			checkRandom[i] = 0;
			buttonElement[i] = 0;
			mainRandomPlaces[i] = 0;
			if (i < 20) {
				checkRan[i] = 0;
			}
		}
		word = UIOfSectionChoose.gm.word.Replace (" ", string.Empty);
		topLeftX = -300;
		topLeftY = 380;
		//UIOfSectionChoose.gm.getWrongLetters ();
		//UIOfSectionChoose.gm.getCorrectLetters ();
		UIOfSectionChoose.gm.getKeyBoard ();
		correctLetters = new Dictionary<int, int> ();//key=placeKeyboard--value=buttonListPlace
		correctLetters = UIOfSectionChoose.gm.correctLetters;
		wrongLetters = new Dictionary<int, int> ();
		wrongLetters = UIOfSectionChoose.gm.wrongLetters;
		keyBoard = new Dictionary<int, int> ();
		keyBoard = UIOfSectionChoose.gm.getKeyBoard();
		if(keyBoard == null){
			UIOfSectionChoose.gm.keyBoard = new Dictionary<int, int>();
			UIOfSectionChoose.gm.correctLetters = new Dictionary<int, int>();
			UIOfSectionChoose.gm.wrongLetters = new Dictionary<int, int>();
			SetMainLetters(word);
			SetOtherLetters();
			
		}
		else{
			if(UIOfSectionChoose.gm.correctLetters == null){
				UIOfSectionChoose.gm.correctLetters = new Dictionary<int, int>();
			}
			if(UIOfSectionChoose.gm.wrongLetters == null){
				UIOfSectionChoose.gm.wrongLetters = new Dictionary<int, int>();
			}
			setKeyBoard(keyBoard,wrongLetters,correctLetters);
		}
		SettingPlatforms ();
	}
	//**set main letters randomly in the keyboard
	public void SetMainLetters(string word1){
		for (int i = 0; i < 33; i++) {//finding the main letters and their amounth (Not Repeated==each letter one time)
			UIOfSectionChoose.gm.buttons.Add(buttonList[i].GetComponentInChildren<Text>().text[0],i);
			for(int j = 0; j < word1.Length;j++){//this loop is for checking the word letters with buttons
				if(buttonList[i].GetComponentInChildren<Text>().text == word1[j].ToString()){
					checkRandom[i]++;//button has been chosen and don't check it to set it on the keyboard again!
					if(checkRandom[i] == 1){
						buttonElement[letter] = i;//buttonElement=wordSet
						letter++; }//for each letter of button we count it one time in letter iterator
				}
			}
		}//**letter=wordSetLength
		//**setting the main letters randomly in the keyboard
		for (int r = 0; r < letter; r++) {//choose random nubers for the word not repeated letters times
			do{
				ran = (int)Random.Range(0,19);//a number for choosing keyboard place randomly
				checkRan[ran]++;//the main houses has been chosen
			}while(checkRan[ran]>1);//this loop is for being certain that same houses won't be chosen in the random again ; because two buttons can't set in same place
			mainRandomPlaces[r]=ran;//the houses for main letters
			Vector3 bMainPos=new Vector3(topLeftX+((Mathf.FloorToInt(ran/2))*(btnHorizontalDis)) , topLeftY+(ran%2)*(btnVerticalDis) ,0.0f);
			buttonList[buttonElement[r]].transform.localPosition=bMainPos;//setting main buttons in random spaces
			UIOfSectionChoose.gm.saveKeyBoard(buttonElement[r],ran);//( buttonList place,int place)
		}
	}//**
	bool allowed=true;//not choosing the places we had chosen for the main letters before
	public void SetOtherLetters(){//setting other buttons randomly in the left positions
		for(int i=0; i<20 ; i++) {
			for(int k=0;k<letter;k++){
				if(i==mainRandomPlaces[k]){
					allowed=false;
				}
			}
			if(allowed == true){
				Vector3 buttonPos = new Vector3(topLeftX+((Mathf.FloorToInt(i/2))*(btnHorizontalDis)) , topLeftY+(i%2)*(btnVerticalDis) ,0.0f);
				//			bool sameButton=false;
				do{
					//sameButton=false;
					random=(int)Random.Range(0,33);//choosing a button among 34-letters buttons randomly
					checkRandom[random]++;//for not choosing same random number
					/*for(int k=0;k<letter;k++){
					if(random==buttonElement[k]){
						sameButton=true;
						Debug.Log("the Same Button is"+random);
					}
				}*/
				}while(checkRandom[random]>1 );// sameButton==true
				buttonList[random].transform.localPosition = buttonPos;
				UIOfSectionChoose.gm.saveKeyBoard(random,i);//( buttonList place,int place)
			}
			allowed=true;
		}
	}
	public void setKeyBoard(Dictionary<int,int> keyBoard,Dictionary<int,int> wrongLetters,Dictionary<int,int> correctLetters){
		Vector3 buttonPos = new Vector3 (0,0,0);
		int[] values = new int[keyBoard.Count];//buttonList
		keyBoard.Values.CopyTo(values, 0);
		int[] keys = new int[keyBoard.Count];//keyBoardPLace
		keyBoard.Keys.CopyTo(keys, 0);
		for(int i=0;i<keyBoard.Count;i++){
			if(wrongLetters!=null && wrongLetters.ContainsKey(keys[i])){
				buttonPos = new Vector3(-1000,-1000,0.0f);//distroy
			}
			else if(correctLetters!=null && correctLetters.ContainsKey(keys[i])){
				for(int k=0;k<word.Length && values[i]==word[k];k++){
					buttonPos = new Vector3 (1200+70*k-1 , 120+k-1 ,0.0f);//platform pos????
				}
			}
			else{
				buttonPos = new Vector3(topLeftX+((Mathf.FloorToInt(keys[i]/2))*(btnHorizontalDis)) , topLeftY+(keys[i]%2)*(btnVerticalDis) ,0.0f);
			}
			buttonList[values[i]].transform.localPosition = buttonPos;
		}
	}
	public void SettingPlatforms(){//setting the platforms at the top of the game
		Vector3 platformPos;
		//Vector3 rabbitPos;
		int k = word.Length-1;
		//int wrong = 0;
		//bool space = false;
		//if(wrongLetters!=null){wrong=wrongLetters.Count;}
		for(int i=0;i<word.Length;i++){
			//if(correctLetters!=null && correctLetters.ContainsValue(UIOfSectionChoose.gm.buttons[word[i]])){
			//Debug.Log("correct letter contains letter"+word[i]);
			//	platformPos = new Vector3 (-1000,-1000,0.0f);//destroy
			//	}
			//	else{
			
			platformPos = new Vector3 (1430+100*k-(word.Length*50) , 125+k ,0.0f);//-(word.Length*50)
			//	}
			platforms[k].transform.localPosition = platformPos;
			Image newRabbit = Instantiate(rabbit, new Vector3(80 * k - (word.Length * 50), k, 0.0f), Quaternion.identity) as Image;
            newRabbit.transform.SetParent(rabbitParent.transform, false);
                UIOfSectionChoose.gm.rabbits.Add(newRabbit);
				//rabbitPos = new Vector3 (1490+80*k-(word.Length*50) , 90+k ,0.0f);//-(word.Length*50)
			//}
			//rabbits[k].transform.localPosition = rabbitPos;
			k--;
		//	space = false;
		}
		
	}
	
}