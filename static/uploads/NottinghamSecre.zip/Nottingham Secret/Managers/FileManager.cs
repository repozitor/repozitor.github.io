﻿using System;
using UnityEngine;
using System.Collections;
using System.IO;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.Security.Cryptography;

public class FileManager : MonoBehaviour
{
	private static	FileManager instance; // Instance of the fileManager
	public JSONObject wordsJson; //words should be static so change the path
	public JSONObject settingsJson; //Dynamic Settings file : lock/unlock/scores
	public JSONObject defaultSettingJson; //static file levels and zones(DEFAULT SETTINGS)
	public JSONObject defaultProfileJson; //profile default json
	public JSONObject levelDesignJson; 
	string fileContents;
	string encrypted;  //encript file and save the string here and save in file
	string decrypted;  //decript the encrypted from file and decrypt and use in game
	public static string word;
	//-----------------------------------------------------------------
	// fileManager()
	// --------------------------------------------------------------------------------------------------- 
	// constructor, creates an instance of fileManager if one does not exist
	// ---------------------------------------------------------------------------------------------------
	public static FileManager Instance
	{
		get
		{
			if (instance == null)
			{
				instance = new GameObject ("fileManager").AddComponent<FileManager> ();
				DontDestroyOnLoad(instance.gameObject);
			}
			
			return instance;
		}
	}	
	// ---------------------------------------------------------------------------------------------------
	public void initialize(){
       File.Delete(Application.persistentDataPath + "/defaultSettings.txt");
       File.Delete(Application.persistentDataPath + "/levelDesign.txt");
       File.Delete(Application.persistentDataPath + "/Profile.txt");
       Debug.Log(File.Exists("HEEEEy"+Application.persistentDataPath + "/Profile.txt"));
       Debug.Log(File.Exists(Application.persistentDataPath + "/levelDesign.txt"));
       Debug.Log(File.Exists(Application.persistentDataPath + "/defaultSettings.txt"));
		wordsJson = new JSONObject(JSONObject.Type.OBJECT);
		settingsJson = new JSONObject();
		defaultSettingJson = new JSONObject();
		defaultProfileJson = new JSONObject();
		levelDesignJson = new JSONObject ();
		makeLevelDesign (levelDesignJson);
		createFile ("levelDesign",levelDesignJson.ToString(),"Assets/Resources/levelDesign.txt");
		makeDefaultSettings (defaultSettingJson);
		createFile ("defaultSettings",defaultSettingJson.ToString(),"Assets/Resources/defaultSettings.txt");
		makeDefaultProfile(defaultProfileJson);
		createFile ("defaultProfile",defaultProfileJson.ToString(),"Assets/Resources/defaultProfile.txt");
        
		//TextAsset defaultProfileTxt = Resources.Load<TextAsset>("defaultProfile");
		//defaultProfileTxt.ToString();
	}
	// ---------------------------------------------------------------------------------------------------
	// OnApplicationQuit()
	// --------------------------------------------------------------------------------------------------- 
	// called when the application quits
	// ---------------------------------------------------------------------------------------------------
	public void OnApplicationQuit()
	{
		destroyInstance();
	}
	// ---------------------------------------------------------------------------------------------------
    public String readPath(string fileName)
    {
        StreamReader inp_stm = new StreamReader(Application.persistentDataPath + "/" + fileName);
        String ans = "";
        while (!inp_stm.EndOfStream)
        {
            string inp_ln = inp_stm.ReadLine();
            ans += inp_ln;
            // Do Something with the input. 
        }

        inp_stm.Close();
        Debug.Log("I have read my path :)");
        return ans;
    }
	// ---------------------------------------------------------------------------------------------------
	// destroyInstance()
	// --------------------------------------------------------------------------------------------------- 
	// destroys the file manager instance
	// ---------------------------------------------------------------------------------------------------
	public void destroyInstance()
	{
		print("fileManager Instance destroyed");
		instance = null;
	}
	// ---------------------------------------------------------------------------------------------------
	public void getJsons(){
		if (checkFile (Application.persistentDataPath + "/levelDesign.txt") == false) {
			Debug.Log ("DataPathMissing");
			levelDesignJson = new JSONObject (Resources.Load<TextAsset> ("levelDesign").ToString ());
			createFile ("levelDesign",String.Empty,Application.persistentDataPath + "/levelDesign.txt");
		} else {
            levelDesignJson = new JSONObject(readPath("levelDesign.txt"));
			if(levelDesignJson.ToString().Equals("null")) {
				Debug.Log("the datapath levelDesign is empty....take from resources");
				levelDesignJson = new JSONObject (Resources.Load<TextAsset> ("levelDesign").ToString ());
			}
		}
        
		if (checkFile (Application.persistentDataPath+"/defaultSettings.txt") == false) {
			Debug.Log ("DataPathMissing");
			defaultSettingJson = new JSONObject(Resources.Load<TextAsset>("defaultSettings").ToString());
			createFile ("defaultSettings",String.Empty,Application.persistentDataPath +"/defaultSettings.txt");
		}
		else { 
            defaultSettingJson = new JSONObject(readPath("defaultSettings.txt"));
			if(defaultSettingJson.ToString().Equals("null")){
				Debug.Log("the datapath settings is empty....take from resources");
				defaultSettingJson = new JSONObject(Resources.Load<TextAsset>("defaultSettings").ToString());
			}
		}
		if (checkFile (Application.persistentDataPath+"/Profile.txt") == false) {
			
			defaultProfileJson = new JSONObject(Resources.Load<TextAsset>("defaultProfile").ToString());
			createFile ("Profile",String.Empty,Application.persistentDataPath +"/Profile");
		}
		else {
            defaultProfileJson = new JSONObject(readPath("Profile.txt"));
            Debug.Log("I read Profile");
			if(defaultProfileJson.ToString().Equals("null")){
				Debug.Log("the datapath profile is empty....take from resources");
				defaultProfileJson = new JSONObject(Resources.Load<TextAsset>("defaultProfile").ToString());
			}
		}
		/*File.Delete (Application.persistentDataPath + "Profile.txt");
		File.Delete (Application.persistentDataPath + "defaultSettings.txt");
		File.Delete (Application.persistentDataPath + "levelDesign.txt");*/
	}
	
	// ---------------------------------------------------------------------------------------------------
	// createFile()
	// --------------------------------------------------------------------------------------------------- 
	// creates a new files
	// ---------------------------------------------------------------------------------------------------
	void createFile( string filename, string fileData , string path) //(wordsFile,wordsJson.ToString() , wordsPath);
	{
		if(checkFile(path) == false)
		{
			print ("!this jsonfile doesn't exist in path!");
			// Create the file
			print("Creating " + filename);
			File.WriteAllText(path, fileData);
		}
	}
	// ---------------------------------------------------------------------------------------------------
	// reInitializeFile()
	// --------------------------------------------------------------------------------------------------- 
	// reInitialize Dynamic file through Game ,changing level
	// ---------------------------------------------------------------------------------------------------
	public void reInitializeProfile(JSONObject json){
		File.WriteAllText(Application.persistentDataPath+"/Profile.txt" , json.ToString());
      //  File.WriteAllText("Assets/Resources/testProfile.txt", json.ToString());
	}
	// ---------------------------------------------------------------------------------------------------
	public void reInitializeLevelDesign(JSONObject json){
		File.WriteAllText( Application.persistentDataPath+"/levelDesign.txt", json.ToString());
      //  File.WriteAllText(  "Assets/Resources/testLevel.txt",json.ToString());
	}
	// ---------------------------------------------------------------------------------------------------
	// processFile()
	// --------------------------------------------------------------------------------------------------- 
	// processes an opened file
	// ---------------------------------------------------------------------------------------------------
	public void processFile(string filepath)
	{
		fileContents = "";
		//print("processing " + filepath);
		
		fileContents = File.ReadAllText(filepath);
		
		//print("Read file which contains: " + fileContents);		
	}
	// ---------------------------------------------------------------------------------------------------
	
	// ---------------------------------------------------------------------------------------------------
	// checkFile()
	// --------------------------------------------------------------------------------------------------- 
	// checks to see whether a file exists
	// ---------------------------------------------------------------------------------------------------
	public bool checkFile(string path)
	{
		if(File.Exists(path))
		{
			return true;
		}
		else
		{
			return false;
		}	
	}
	//------------------------------------------------------------------------------------------------------
	public void makeDefaultProfile(JSONObject Profile){//profile{A0:{state:Active,Z0:{State:Active,L0:{State:Active}}}}
		List<JSONObject> A = new List<JSONObject>();
		JSONObject Z = new JSONObject();
		JSONObject L = new JSONObject();
		string state = "State";
		for (int i=0; i<3; i++) {
			A.Add(new JSONObject());
			A [i].AddField (state,State.Active.ToString());
		}
		Z.AddField (state,State.Active.ToString());
		L.AddField (state,State.Active.ToString());
		Z.AddField ((1).ToString(), L);
		for (int i=0; i<3; i++) {
			A [i].AddField ((1).ToString (), Z);
		}
		for (int i=0; i<3; i++) {
			Profile.AddField ((i+1).ToString (), A[i]);
		}
	}
	// ---------------------------------------------------------------------------------------------------
	public void makeDefaultSettings(JSONObject GameJson)////Game{L{time,hint1,hint2,score,State}}
	{
		
		string buttonVoice = "buttonVoice";
		string gameVoice = "gameVoice";
		GameJson.AddField (buttonVoice,1);
		GameJson.AddField (gameVoice,1);
		
	}
	public void makeLevelDesign(JSONObject LevelDesignJson)////LevelDesign{L{time,hint1,hint2,score,State}}
	{
		List<JSONObject> A = new List<JSONObject>();
		List<JSONObject> Z = new List<JSONObject>();
		List<JSONObject> L = new List<JSONObject>();
		string time = "time";
		string score = "score";
		string hint1 = "hint1";
		string hint2 = "hint2";
		JSONObject correctLetters=new JSONObject();
		JSONObject wrongLetters=new JSONObject();
		JSONObject keyboard=new JSONObject();
		for (int i=0; i<20; i++) {
			L.Add (new JSONObject ());
			L [i].AddField (time, 30);
			L [i].AddField (score, 0);
			L [i].AddField (hint1, false);
			L [i].AddField (hint2, false); 
			L [i].AddField ("correctLetters",correctLetters);
			L [i].AddField ("wrongLetters",wrongLetters);
			L [i].AddField ("keyBoard",keyboard);
		}
		
		for (int i=0; i<3; i++) {
			Z.Add(new JSONObject());
			for (int j =0; j<L.Count; j++) {
				Z [i].AddField ((j+1).ToString(), L [j]);//"L" + j
			}
		}
		for (int i=0; i<3; i++) {
			A.Add(new JSONObject());
			for (int j =0; j<Z.Count; j++) {
				A[i].AddField ((j+1).ToString(), Z [j]);//"L" + j
			}
			A [i].AddField ("hero",true);
		}
		
		int k=0;
		for (; k<A.Count; k++) {//count=3
			levelDesignJson.AddField ((k+1).ToString (), A [k]);//"A1"
		}
		levelDesignJson.AddField ("totalScore",0);//totalScore
		levelDesignJson.AddField ("downloaded",true);//toturial
	}
	//-----------------------------------------------------------------------------------------------
	public string encryptData(string toEncrypt)
	{
		byte[] keyArray = UTF8Encoding.UTF8.GetBytes("12345678901234567890123456789012");
		
		// 256-AES key
		byte[] toEncryptArray = UTF8Encoding.UTF8.GetBytes(toEncrypt);
		RijndaelManaged rDel = new RijndaelManaged();
		
		rDel.Key = keyArray;
		rDel.Mode = CipherMode.ECB;
		
		rDel.Padding = PaddingMode.PKCS7;
		
		ICryptoTransform cTransform = rDel.CreateEncryptor();
		byte[] resultArray = cTransform.TransformFinalBlock (toEncryptArray, 0, toEncryptArray.Length);
		
		return Convert.ToBase64String (resultArray, 0, resultArray.Length);
	}
	
	public string decryptData(string toDecrypt)
	{
		byte[] keyArray = UTF8Encoding.UTF8.GetBytes ("12345678901234567890123456789012");
		
		// AES-256 key
		byte[] toEncryptArray = Convert.FromBase64String (toDecrypt);
		RijndaelManaged rDel = new RijndaelManaged ();
		rDel.Key = keyArray;
		rDel.Mode = CipherMode.ECB;
		
		rDel.Padding = PaddingMode.PKCS7;
		
		// better lang support
		ICryptoTransform cTransform = rDel.CreateDecryptor ();
		
		byte[] resultArray = cTransform.TransformFinalBlock (toEncryptArray, 0, toEncryptArray.Length);
		
		return UTF8Encoding.UTF8.GetString (resultArray);
	}
	
}