﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class UIManager : MonoBehaviour 
{
	List<UIPanel> prefabs = new List<UIPanel> ();
	Dictionary<PanelType, UIPanel> panelsDict = new Dictionary<PanelType, UIPanel> ();
	UIPanel activePanel = null;
	
	void Start(){
		DontDestroyOnLoad (this);
	}
	
	void OnLevelWasLoaded(int level)
	{
		switch (level) 
		{
		case 1:
			ChangePanel(PanelType.MainMenu);
			break;
		case 2:
			ChangePanel(PanelType.Game);
			break;
		case 3:
			ChangePanel(PanelType.SectionChoose);
			break;
		default:
			
			break;
		}
	}
	
	public void ChangePanel(PanelType type)
	{
		if (!panelsDict.ContainsKey(type))
		{
			FetchAndInstantiate(type);
		}
		
		if (activePanel != null)
		{
			activePanel.gameObject.SetActive (false);
		}
		bool flag = false;
		foreach (KeyValuePair<PanelType, UIPanel> item in panelsDict)
		{
			if (item.Key == type) 
			{
				item.Value.gameObject.SetActive(true);
				activePanel = item.Value;
				flag = true;
				break;
			}	
		}
	}
	
	void FetchAndInstantiate(PanelType type)
	{
		FetchPrefabs ();
		
		for (int i = 0; i < prefabs.Count; i++) 
		{
			if (prefabs[i].Type == type)
			{
				UIPanel temp = Instantiate(prefabs[i]);	
				temp.gameObject.SetActive(false);
				panelsDict.Add(type,temp);
				break;
			}
		}
	}
	
	void FetchPrefabs()
	{
		if (prefabs.Count > 0) 
		{
			return;
		}
		
		UIPanel[] temp = Resources.LoadAll<UIPanel> ("Prefab");
		for (int i = 0; i < temp.Length; i++) 
		{
			prefabs.Add(temp[i]);
		}
	}
}
