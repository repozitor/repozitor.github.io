﻿using UnityEngine;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
public enum GameState {Loading,MainMenu,Game,PauseMenu,Settings,Gallery,Loose,Win,LevelMenu,AreaMenu,SectionMenu};
public enum SoundState {Menu , Level , Scream};

public enum ScoreState {Easy, Difficult};
//if entered in the level-> levelDesignJson ["downloaded"].SetField ("downloaded",false);
public class GameManager : MonoBehaviour 
{
	public GameState currentGameState;
    private float vol = 1;
    public int score = 0;
    public float time;
	public string[] alphabetFarsi;
	public string[] alphabetEnglish;
	public JSONObject wordJson;
	public JSONObject levelDesignJson;
	public JSONObject settingsJson;
	public JSONObject profileJson;
	public string word;
	public int lives;
    public List<Image> rabbits;
	public  Profile profile;
	public  int currentArea;
	public  int currentZone;
	public  int currentLevel;
	public string sample = "";
    public bool activeLevel = true;
	public Dictionary<string,string> alphabet;
	public Dictionary<int,int> correctLetters;
	public Dictionary<int,int> wrongLetters;
	public Dictionary<int,int> keyBoard;//place on keyBoard , place on list
	public Dictionary<char,int> buttons;//for saving button numbers in the main list (from 1 to 33)
    public AudioClip menu;
    public AudioClip level;
    public AudioClip scream;
    public string hint1;
    public string hint2;
	void Start () 
	{
		//FileManager.Instance.initialize();
		load ();
		set ();
		currentZone = 1;
		correctLetters = new Dictionary<int, int> ();
		wrongLetters = new Dictionary<int, int> ();
		keyBoard = new Dictionary<int, int> ();
		//Debug.Log("I AM CHECKIIIIIING!"+profileJson[1].keys[0]);  // 1=>print:2  start element from 0
		DontDestroyOnLoad (this);
		currentGameState = GameState.Loading;
		setStateMainMenu ();
		SceneManager.LoadSceneAsync("MainMenu");
        soundstate(SoundState.Menu);
		currentGameState = GameState.MainMenu;
	}
    public void soundstate(SoundState soundState)
    {

        switch(soundState){
     case SoundState.Menu: 
        // Debug.Log("SoundState: Menu");
         SoundManager2D.stopAllLoopingSounds();
         SoundManager2D.playLoopingSound(menu, "menu", 1,vol);
         break;
     case SoundState.Level:
         //Debug.Log("SoundState: Level");
         SoundManager2D.stopAllLoopingSounds();
         SoundManager2D.playLoopingSound(level, "level",1, vol);
         break;
     case SoundState.Scream:
         //Debug.Log("SoundState: scream");
         SoundManager2D.playOneShotSound(UIOfSectionChoose.gm.scream, vol);
         break;
     default:
         //Debug.Log("NO Sound States!");
         break;
        }

    }
    public void soundDegree(float volume){
       // SoundManager2D.stopAllLoopingSounds();
        vol = volume;
        SoundManager2D.playLoopingSound(menu, "menu",1, vol );
}

    public void checkActive(float time)
    {
        ScoreState scoreState;
        if(currentZone == 3){ scoreState = ScoreState.Difficult;}
        else{
            scoreState = ScoreState.Easy;
        }
        
        if (profile.areaDictionary[currentArea].zoneDictionary[currentZone].levelDictionary[currentLevel].levelState == State.Active)
        {
            setScore(scoreState , time);
        }
        else
        {
            Debug.Log("passed the level one more time!");
        }
    }
    public void setScore(ScoreState scoreState , float time)
    {
  
        switch (scoreState)
        {
            case ScoreState.Easy:
                score += 100;
                score += (int)(time);
                Debug.Log("ScoreState: easy/medium" + score);
                break;
            case ScoreState.Difficult:
                score += 100;
                score += 2*((int)(time));
                Debug.Log("ScoreState: difficult" + score);
                break;
            default:
                Debug.Log("NO SCore States!" + score);
                break;
        }
        
    }

	public Dictionary<int,int> getKeyBoard(){//from profile
		//Dictionary<int,char> keyBoard = new Dictionary<int,char>();
		keyBoard = profile.areaDictionary [currentArea].zoneDictionary [currentZone].levelDictionary [currentLevel].keyBoard;
		return keyBoard;
	}

	public void saveKeyBoard(int letter,int place){//place=place on keybord
		UIOfSectionChoose.gm.keyBoard.Add (place ,letter);
		//Debug.Log ("currentLevel "+currentLevel);
		profile.areaDictionary [currentArea].zoneDictionary [currentZone].levelDictionary [currentLevel].keyBoard= keyBoard;
		levelDesignJson [currentArea.ToString ()] [currentZone.ToString ()] [currentLevel.ToString ()]["keyBoard"].AddField(place.ToString(),letter.ToString());
        FileManager.Instance.reInitializeLevelDesign (levelDesignJson);
	}
	void setNextArea(){//update profile
		profile.areaDictionary [currentArea].areaState = State.Finished;
		profileJson[currentArea.ToString()].SetField (currentArea.ToString(),State.Finished.ToString());
		FileManager.Instance.reInitializeProfile (profileJson);
	}
	
	void setNextZone(){//update profile
		profile.areaDictionary [currentArea].zoneDictionary[currentZone].zoneState = State.Finished;
		profileJson [currentArea.ToString()][currentZone.ToString()].SetField ("State",State.Finished.ToString());
		FileManager.Instance.reInitializeProfile (profileJson);
        UIOfSectionChoose.gm.currentZone++;
		if (currentZone <= profile.areaDictionary[currentArea].zoneDictionary.Count) {
			profile.areaDictionary[currentArea].zoneDictionary [currentZone].zoneState = State.Active;
            JSONObject zoneJ = new JSONObject();
            zoneJ.AddField("State",State.Active.ToString());
            JSONObject levelJZ = new JSONObject();
            levelJZ.AddField("State",State.Active.ToString());
            zoneJ.AddField((1).ToString(),levelJZ);//lvlNum=1
			profileJson[currentArea.ToString()].AddField (currentZone.ToString() , zoneJ);
            Debug.Log("WHY REDICIOULUS  ERRORS!: "+ currentArea +" "+currentZone +" "+currentLevel);
			FileManager.Instance.reInitializeProfile(profileJson);
			Debug.Log ("welcome to next Zone:) "+profileJson.ToString());
		} else {
			Debug.Log("this Area finished!!!");
		}
	}
    public bool nextLevelPermission()
    {
        if(profile.areaDictionary[currentArea].zoneDictionary[currentZone].levelDictionary[currentLevel].levelState == State.Finished){
            Debug.Log("Not Permitted");
            return false;
        }
        else{
            Debug.Log(":)Permitted");
            return true;
        }
    }
    public void goNextLevel()
    {
        UIOfSectionChoose.gm.currentLevel++;
        if (currentLevel > profile.areaDictionary[currentArea].zoneDictionary[currentZone].levelDictionary.Count)
        {
            UIOfSectionChoose.gm.currentZone++;
            UIOfSectionChoose.gm.currentLevel = 1;
        }
    }
	public void setNextLevel(){//update profile
		profile.areaDictionary[currentArea].zoneDictionary[currentZone].levelDictionary[currentLevel].levelState = State.Finished;
        profileJson[currentArea.ToString()][currentZone.ToString()][currentLevel.ToString()].SetField ("State",State.Finished.ToString());
        FileManager.Instance.reInitializeProfile (profileJson);
		UIOfSectionChoose.gm.currentLevel++;
		if(currentLevel <=  profile.areaDictionary[currentArea].zoneDictionary[currentZone].levelDictionary.Count){
			profile.areaDictionary[currentArea].zoneDictionary[currentZone].levelDictionary[currentLevel].levelState = State.Active;
            JSONObject levelJ = new JSONObject();
            levelJ.AddField("State",State.Active.ToString());
			profileJson[currentArea.ToString()][currentZone.ToString()].AddField(currentLevel.ToString(),levelJ);
			FileManager.Instance.reInitializeProfile (profileJson);
		}
		else{
            UIOfSectionChoose.gm.currentLevel = 1;
			setNextZone();
			Debug.Log ("welcome to next Zone:) "+settingsJson.ToString());
		}
		//profile.createFile
	}
	
	public void load(){
		FileManager.Instance.getJsons ();
		settingsJson = FileManager.Instance.defaultSettingJson;
		profileJson = FileManager.Instance.defaultProfileJson;
		levelDesignJson = FileManager.Instance.levelDesignJson;
        Debug.Log("Settings"+settingsJson.ToString());
        Debug.Log("prfile"+profileJson.ToString());
	}
	public void setCurrents(int area){//should be invoked while clicked 
		currentArea = area;
		currentZone = profile.areaDictionary [currentArea].currentZone;
		currentLevel = profile.areaDictionary [currentArea].zoneDictionary [currentZone].currentLevel;
	}
	public void set(){
		profile = new Profile (profileJson,levelDesignJson);
	}
	
	public void setStateGame(){
		currentGameState = GameState.Game;
		//Debug.Log ("GameState: Game");
	}
	public void setStateLoading(){
		currentGameState = GameState.Loading;
		//Debug.Log ("GameState: Loading");
	}
	public void setStateMainMenu(){
		currentGameState = GameState.MainMenu;
		//Debug.Log ("GameState: MainMenu");
	}
	public void setStatePauseMenu(){
		currentGameState = GameState.PauseMenu;
		//Debug.Log ("GameState: PauseManu");
	}
	public void setStateSettings(){
		currentGameState = GameState.Settings;
		//Debug.Log ("GameState: Settings");
	}
	public void setStateGallery(){
		currentGameState = GameState.Gallery;
		//Debug.Log ("GameState: Gallery");
	}
	public void setStateLoose(){
		currentGameState = GameState.Loose;
		//Debug.Log ("GameState: Loose");
	}
	public void setStateWin(){
		currentGameState = GameState.Win;
		//Debug.Log ("GameState: Win");
	}
	

}