﻿using UnityEngine;
using System.Collections.Generic;
//using System.Diagnostics;
using System.Collections;
using System.Text;

public enum State {Locked,Active,Finished}

public class Profile {
	
	public Dictionary<int,Area> areaDictionary;
	//constructor
	public Profile(JSONObject defaultProfileJson,JSONObject levelDesignJson){
		areaDictionary = new Dictionary<int,Area> ();
		State areaState;
		int totalScore;
		bool downloaded;
		int i = 0;
		for (; i<defaultProfileJson.Count; i++) {//count=3 areas
			
			areaDictionary.Add ((i+1), new Area ((JSONObject)(defaultProfileJson [i]), (JSONObject)(levelDesignJson [i])));//dict(1,Area(AreaProfile,AreaLevelDesign))
			areaState  = (State)System.Enum.Parse (typeof(State), defaultProfileJson [i] ["State"].ToString ().Replace ("\"", string.Empty));
			areaDictionary [(i+1)].areaState  = areaState;
			areaDictionary[(i+1)].hero = bool.Parse(levelDesignJson[i]["hero"].ToString());
			
		}
		//Debug.Log("This is the rest of levelDesign json "+i);
		for (; i<levelDesignJson.Count-2; i++) {//one less for ignoring total score   //count=2=totalScore+downloaded(toturial)
            Debug.Log("this shoud not have been happened!!!!! "+ (levelDesignJson.Count-2));
			areaDictionary.Add ((i+1), new Area (null, levelDesignJson [i]));
			areaDictionary [i+1].areaState = State.Locked;
			areaDictionary [i+1].hero = bool.Parse(levelDesignJson[i]["hero"].ToString());
		}
	//	Debug.Log("final i after leveldesignjsons: "+i+"    LEVELDESIGN COUNT: "+levelDesignJson.Count);
		totalScore = int.Parse(levelDesignJson ["totalScore"].ToString());//levelDesignJson [i].ToString()
		//i++;
		downloaded = bool.Parse(levelDesignJson["downloaded"].ToString());//levelDesignJson [i].ToString()
		
	}
	
	State getState(State state){
		State s;
		if (state == State.Active) {
			s = State.Active;
		} else if (state == State.Finished) {
			s = State.Finished;
		} else {
			s=State.Locked;
		}
		return s;
	}
}

public class Area{
	public int currentZone = 0;
	public State areaState; 
	public bool hero;
	public Dictionary<int,Zone> zoneDictionary;
	public Area(JSONObject defaultAreaJson ,JSONObject levelDesignJson){
		zoneDictionary = new Dictionary<int,Zone> ();
		State zoneState;
		int i=0;
		if (defaultAreaJson != null) {
            Debug.Log("FUCk2: " + "count: " + (defaultAreaJson.Count - 1) + defaultAreaJson);
			for (; i < (defaultAreaJson.Count - 1); i++) {//ignoring State
                //JSONObject subDefaultArea = defaultAreaJson [i + 1];//ignore state this is zoneJson///downHEREEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE2222222
				zoneDictionary.Add ((i + 1), new Zone ((JSONObject)defaultAreaJson [(i + 1).ToString()], (JSONObject)levelDesignJson [(i+1).ToString()]));//dict(1,Zone(ZoneProfile,ZoneLevelDesign))
                Debug.Log("FUCK ERROR!  " +" "+(i+1)+" "+defaultAreaJson[(i + 1).ToString()]);
				zoneState = (State)System.Enum.Parse (typeof(State), defaultAreaJson [(i + 1).ToString()] ["State"].ToString ().Replace ("\"", string.Empty));
				zoneDictionary [(i + 1)].zoneState = zoneState;
                Debug.Log("Ey BAAB: "+ i);
			}
			currentZone = i;//activeOne
		}
        for (; i < levelDesignJson.Count - 1; i++)
        {//count=3=Zones ignoring hero///downHEREEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE
			zoneDictionary.Add ((i+1), new Zone (null, levelDesignJson [(i+1).ToString()]));
			zoneDictionary [i+1].zoneState = State.Locked;
		}
	}
	public static State getState(State state){
		State s;
		if (state == State.Active) {
			s = State.Active;
		} else if (state == State.Finished) {
			s = State.Finished;
		} else {
			s=State.Locked;
		}
		return s;
	}
}
public class Zone{
	public Dictionary<int,Level> levelDictionary;
	public int currentLevel=0;
	public State zoneState; 
	public Zone(JSONObject defaultZoneJson,JSONObject levelDesignJson){
		levelDictionary = new Dictionary<int,Level>();
		State levelState;
		int i=0;
		if(defaultZoneJson!=null){
			for ( ;i<defaultZoneJson.Count-1 ; i++) {//defaultAreaJson!=null//ignore state
				levelDictionary.Add ((i+1), new Level ());///downHEREEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE
                levelDictionary[i + 1].levelState = (State)System.Enum.Parse(typeof(State), defaultZoneJson[(i+1).ToString()]["State"].ToString().Replace("\"", string.Empty));// State.Active;
				levelDictionary[i+1].hint1 = bool.Parse(levelDesignJson[i]["hint1"].ToString().Replace ("\"", string.Empty));
				levelDictionary[i+1].hint2 = bool.Parse(levelDesignJson[i]["hint2"].ToString().Replace ("\"", string.Empty));
				levelDictionary[i+1].time = int.Parse(levelDesignJson[i]["time"].ToString ().Replace ("\"", string.Empty));
				levelDictionary[i+1].score = int.Parse(levelDesignJson[i]["score"].ToString().Replace ("\"", string.Empty));
				if(levelDesignJson[i]["correctLetters"].Count>0){
					levelDictionary[i+1].correctLetters = new Dictionary<int, int>();
					for(int k=0;k<levelDesignJson[i]["correctLetters"].Count;k++){
						levelDictionary[i+1].correctLetters.Add(int.Parse(levelDesignJson[i]["correctLetters"].keys[k].ToString()),int.Parse(levelDesignJson[i]["correctLetters"][k].ToString().Replace ("\"", string.Empty)));
					}
				}
				else{
					levelDictionary[i+1].correctLetters=null;
				}
				if(levelDesignJson[i]["wrongLetters"].Count>0){
					levelDictionary[i+1].wrongLetters = new Dictionary<int, int>();
					for(int k=0;k<levelDesignJson[i]["wrongLetters"].Count;k++){
						levelDictionary[i+1].wrongLetters.Add(int.Parse (levelDesignJson[i]["wrongLetters"].keys[k].ToString()),int.Parse(levelDesignJson[i]["wrongLetters"][k].ToString().Replace ("\"", string.Empty)));
					}}
				else{
					levelDictionary[i+1].wrongLetters=null;
				}
				if(levelDesignJson[i]["keyBoard"].Count>0){
					levelDictionary[i+1].keyBoard = new Dictionary<int, int>();
					for(int k=0;k<levelDesignJson[i]["keyBoard"].Count;k++){
						levelDictionary[i+1].keyBoard.Add(int.Parse (levelDesignJson[i]["keyBoard"].keys[k].ToString()),int.Parse(levelDesignJson[i]["keyBoard"][k].ToString().Replace ("\"", string.Empty)));
					}}
				else{
					levelDictionary[i+1].wrongLetters=null;
				}
			}
			//	levelDictionary [i].levelState=State.Finished;//couldn't write 
			currentLevel=i;//active level
		}
	//	Debug.Log ("PROFILE C#: "+levelDesignJson.Count);
		for(;i<levelDesignJson.Count;i++){
			levelDictionary.Add((i+1),new Level());
			levelDictionary[i+1].levelState = State.Locked;
			levelDictionary[i+1].hint1 = bool.Parse(levelDesignJson[i]["hint1"].ToString().Replace ("\"", string.Empty));
			levelDictionary[i+1].hint2 = bool.Parse(levelDesignJson[i]["hint2"].ToString().Replace ("\"", string.Empty));
			levelDictionary[i+1].time = int.Parse(levelDesignJson[i]["time"].ToString ().Replace ("\"", string.Empty));
			levelDictionary[i+1].score = int.Parse(levelDesignJson[i]["score"].ToString().Replace ("\"", string.Empty));
			if(levelDesignJson[i]["correctLetters"].Count>0){
				levelDictionary[i+1].correctLetters = new Dictionary<int, int>();
				for(int k=0;k<levelDesignJson[i]["correctLetters"].Count;k++){
					levelDictionary[i+1].correctLetters.Add(int.Parse(levelDesignJson[i]["correctLetters"].keys[k].ToString()),int.Parse(levelDesignJson[i]["correctLetters"][k].ToString().Replace ("\"", string.Empty)));
				}
			}
			else{
				levelDictionary[i+1].correctLetters=null;
			}
			if(levelDesignJson[i]["wrongLetters"].Count>0){
				levelDictionary[i+1].wrongLetters = new Dictionary<int, int>();
				for(int k=0;k<levelDesignJson[i]["wrongLetters"].Count;k++){
					levelDictionary[i+1].wrongLetters.Add(int.Parse (levelDesignJson[i]["wrongLetters"].keys[k].ToString()),int.Parse(levelDesignJson[i]["wrongLetters"][k].ToString().Replace ("\"", string.Empty)));
				}}
			else{
				levelDictionary[i+1].wrongLetters=null;
			}
			if(levelDesignJson[i]["keyBoard"].Count>0){
				levelDictionary[i+1].keyBoard = new Dictionary<int, int>();
				for(int k=0;k<levelDesignJson[i]["keyBoard"].Count;k++){
					levelDictionary[i+1].keyBoard.Add(int.Parse (levelDesignJson[i]["keyBoard"].keys[k].ToString()),int.Parse(levelDesignJson[i]["keyBoard"][k].ToString().Replace ("\"", string.Empty)));
				}
			}
			else{
				levelDictionary[i+1].wrongLetters=null;
			}
		}
	}
	public static State getState(State state){
		State s;
		if (state == State.Active) {
			s = State.Active;
		} else if (state == State.Finished) {
			s = State.Finished;
		} else {
			s=State.Locked;
		}
		return s;
	}
}
public class Level{
	public State levelState;
	public int time;
	public int score;
	public bool hint1;
	public bool hint2;
	public Dictionary<int,int> correctLetters;
	public Dictionary<int,int> wrongLetters;
	public Dictionary<int,int> keyBoard;
	
}