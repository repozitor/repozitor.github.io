﻿   using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class UIOFGame : UIPanel {
	public GameObject Pnl_Help;
	public Image BackGround;
	public Image WinBackGround;
	public Image GameOverBackGround;
	public Text Help_txt;
	public Text Level_txt;
	public GameObject Help_word;
	int Level1;
	Sprite[] ReadImage;
	Sprite[] ReadImage1;//winbackgrounds
	Sprite[] ReadImage2;//gameoverbackground;
	int zoneNum = UIOfSectionChoose.gm.currentZone;
	int Level = UIOfSectionChoose.gm.currentLevel;
    public Text Score_txt;
    int i = 0;
    int n = UIOfSectionChoose.gm.score;
	public void Start(){
        Score_txt.text = i.ToString();
		if (zoneNum == 1) {
			Level1 = Level;
		} else if (zoneNum == 2 || zoneNum == 3) {
			Level1 = Level + zoneNum * 10;
		}
		Level_txt.text = Level1.ToString ();
		ReadImage = Resources.LoadAll<Sprite> ("GameBackGrounds");
		ReadImage1 = Resources.LoadAll<Sprite> ("WinBackGrounds");
		ReadImage2 = Resources.LoadAll<Sprite> ("GameOverBackGrounds");
		Pnl_Help.SetActive(false);
		if (zoneNum == 1) {
			BackGround.sprite = ReadImage[0];
			WinBackGround.sprite = ReadImage1[0];
			GameOverBackGround.sprite = ReadImage2[0];
		} 
		else if (zoneNum == 2) {
			BackGround.sprite = ReadImage[1];
			WinBackGround.sprite = ReadImage1[1];
			GameOverBackGround.sprite = ReadImage2[1];
		} 
		else if (zoneNum == 3) {
			BackGround.sprite = ReadImage[2];
			WinBackGround.sprite = ReadImage1[2];
			GameOverBackGround.sprite = ReadImage2[2];
		}
	}
	public void GoToMenu(){
        UIOfSectionChoose.gm.soundstate(SoundState.Menu);
        UIOfSectionChoose.gm.currentGameState = GameState.LevelMenu;
		SceneManager.LoadSceneAsync("MainMenu");
	}
	public void Help(){
		Pnl_Help.SetActive(true);
		UIOfSectionChoose.gm.currentGameState = GameState.PauseMenu;
	}
	public void Close_Pnl_Help(){
		Pnl_Help.SetActive(false);
		UIOfSectionChoose.gm.currentGameState = GameState.Game;
	}
	public void Try_Again(){
        SceneManager.LoadSceneAsync("Game");
		UIOfSectionChoose.gm.currentGameState = GameState.Game;
	}
	public void ShowHelp(){
		Pnl_Help.SetActive (false);
		Help_txt.text = "مری خوله:)";//joloye mosavi text helpeto vared kon:)
		Help_word.SetActive (true);
		UIOfSectionChoose.gm.currentGameState = GameState.Game;
	}
    public void NextLevel()
    {
       // Debug.Log("word of next level: " + UIOfSectionChoose.gm.currentLevel);
        int levelNum = UIOfSectionChoose.gm.currentLevel;
        int areaNum = UIOfSectionChoose.gm.currentArea;
        int zoneNum = UIOfSectionChoose.gm.currentZone;
        UIOfSectionChoose.gm.word = (TxtToDictionary.mainJson[areaNum - 1][zoneNum - 1][levelNum - 1].ToString()).Replace("\"", string.Empty);
       // Debug.Log("Next word: " + UIOfSectionChoose.gm.word);
        SceneManager.LoadSceneAsync("Game");
        UIOfSectionChoose.gm.currentGameState = GameState.Game;
    }
    public void Update()
    {
        if (i < (UIOfSectionChoose.gm.score - n))
        {
            Score_txt.text = "+" + i.ToString();
            i++;
        }
        else
        {
            Score_txt.text = "+" + (UIOfSectionChoose.gm.score - n).ToString();
        }
    }
}