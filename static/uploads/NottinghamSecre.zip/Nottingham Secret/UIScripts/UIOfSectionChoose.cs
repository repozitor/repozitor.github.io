﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
public class UIOfSectionChoose : UIPanel {
	public static GameManager gm;
    public GameObject LevelSelection;
    public GameObject MainMenu;
    public GameObject SectionChoose;
    public Text Score_txt;
    public Slider myslider;
	public void Start()
	{
		gm = GameObject.FindGameObjectWithTag ("GameManager").GetComponent<GameManager> ();
        Score_txt.text = gm.score.ToString();
		//DontDestroyOnLoad(this);
	}
	public void BackToMenu(){
        MainMenu.SetActive(true);
        SectionChoose.SetActive(false);
        UIOfSectionChoose.gm.currentGameState = GameState.MainMenu;
	}
	public void GoToLevelSelection1(){
		gm.setCurrents (1);
        LevelSelection.SetActive(true);
        SectionChoose.SetActive(false);
        UIOfSectionChoose.gm.currentGameState = GameState.LevelMenu;
	}
	public void GoToLevelSelection2(){
		gm.setCurrents (2);
        LevelSelection.SetActive(true);
        SectionChoose.SetActive(false);
        UIOfSectionChoose.gm.currentGameState = GameState.LevelMenu;
	}
	public void GoToLevelSelection3(){
		gm.setCurrents (3);
        LevelSelection.SetActive(true);
        SectionChoose.SetActive(false);
        UIOfSectionChoose.gm.currentGameState = GameState.LevelMenu;
	}
    public void volume()
    {
        UIOfSectionChoose.gm.soundDegree(myslider.normalizedValue);
    }
}
