﻿using UnityEngine;
using System.Collections;
using System.Configuration;
public class Setting : MonoBehaviour {

	// Use this for initialization


	// Update is called once per frame

}
