﻿using UnityEngine;
using System.Collections;

public enum PanelType{MainMenu, Game, SectionChoose};

public class UIPanel : MonoBehaviour 
{
	[SerializeField]
	PanelType type;
	public PanelType Type{get{return type;}
	}
}
