﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI ;
public class UIManagerScript : UIPanel {

	public Animator dialog;
	public Animator Animation;
	public GameObject SectionChoose;
    public GameObject MainMenu;
    public GameObject LevelSelection;
	void OnLevelWasLoaded(int level)
	{
		
	}

   
	
	public void StartGame()
	{
        UIOfSectionChoose.gm.currentGameState = GameState.SectionMenu;
        MainMenu.SetActive(false);
		SectionChoose.SetActive (true);
	}
	public void Exit(){
		Application.Quit();
	}
	public void OpenAndCloseSettings()
	{
		dialog.enabled = true;
		
		bool isHidden = dialog.GetBool("isHidden");
		dialog.SetBool("isHidden", !isHidden);
	}
	void Update() {
        if (UIOfSectionChoose.gm.currentGameState == GameState.LevelMenu)
        {
            MainMenu.SetActive(false);
            LevelSelection.SetActive(true);
        }
        if (UIOfSectionChoose.gm.currentGameState == GameState.SectionMenu)
        {
            MainMenu.SetActive(false);
            SectionChoose.SetActive(true);
        }
		/*if (Input.deviceOrientation == DeviceOrientation.LandscapeLeft) {
			ScreenOrientation LandscapeLeft;
		}
		else if (Input.deviceOrientation == DeviceOrientation.LandscapeRight) {
			ScreenOrientation LandscapeRight;
		}*/
	}
}