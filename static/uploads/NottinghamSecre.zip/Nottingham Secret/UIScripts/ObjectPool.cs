﻿  using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class ObjectPool : MonoBehaviour {
	int zoneNum=1;
	int countName = 1;
	int levelNum;
	int areaNum;
	public Button MyButtonPrefab;
	public RectTransform ParentPanel; //panel(1)
	public int poolSize = 6;
	public GameObject instances; //panel(1)
	public GameObject Parent;    //fool
	public bool prePopulate;
	GameObject clone;
	private List<GameObject> poolInstances = new List<GameObject>();
	GameObject[] cloneInstances;
	GameObject[] LockImages;
	Sprite[] ReadImage;
	Sprite[] ReadImage1;//images of button of active and fineshed level
	Sprite[] ReadImage2;//images of button of lock level
	public Image image;
	public Image LockImage;
	public Text LevelText;
	int i;
    public GameObject SectionChoose;
    public GameObject LevelSelection;
    Animator FadeIn;
	void Start () {
		ReadImage = Resources.LoadAll<Sprite> ("Images");
		ReadImage1 = Resources.LoadAll<Sprite> ("LevelButtonimages");
		ReadImage2 = Resources.LoadAll<Sprite> ("LockImages");
		if (prePopulate)
		{
			Debug.Log("prePopulate");
			PrePolpulate();
		}
	}
	
	
	Vector2[] pos = { new Vector2 (290,-210),new Vector2 (450, -215),new Vector2 (454,-387),new Vector2 (456,-559),new Vector2 (625,-566)
		,new Vector2 (798,-566),new Vector2 (797,-405),new Vector2 (970,-400),new Vector2 (969,-230),new Vector2 (1144,-225)};
   
    Vector2[] pos1 = { new Vector2 (285,-210),new Vector2 (445, -215),new Vector2 (450,-387),new Vector2 (450,-559),new Vector2 (620,-566)
		,new Vector2 (795,-566),new Vector2 (795,-405),new Vector2 (965,-400),new Vector2 (960,-230),new Vector2 (1140,-225)};
	
	public void PrePolpulate(){
		for (i = 0; i < poolSize; i++){
			image.sprite = ReadImage[i];
			clone = CreateInstance();
			//cloneInstances[i] = clone;
			//clone.SetActive(false);
			clone.transform.SetParent(Parent.transform); //set position
			clone.transform.localScale = new Vector3(1,1,1);
			for (int k=0; k< pos.Length; k++) {
				areaNum =  UIOfSectionChoose.gm.currentArea;
				Button newButton = (Button)Instantiate (MyButtonPrefab, pos [k], Quaternion.identity);
				newButton.transform.SetParent (clone.transform,false);
				newButton.transform.localScale = new Vector3 (1, 1, 1);
				newButton.name = countName.ToString();
				countName += 1;
				//LevelText.text = countName.ToString();
				if(int.Parse(newButton.name)<=20){
					zoneNum = 1;
				}
                else if (int.Parse(newButton.name) > 20 && int.Parse(newButton.name) <= 40)
                {
					zoneNum = 2;//2
				}
				else if(int.Parse(newButton.name)>40){
					zoneNum = 3;//3
				}
				UIOfSectionChoose.gm.currentZone=zoneNum;
                levelNum = ((int.Parse(newButton.name) - 1) % 20) + 1;
				UIOfSectionChoose.gm.currentLevel=levelNum;
				if(zoneNum == 1 && UIOfSectionChoose.gm.profile.areaDictionary[areaNum].zoneDictionary[zoneNum].levelDictionary[levelNum].levelState == State.Locked){
        
                    Image newImage = (Image)Instantiate (LockImage, pos [k], Quaternion.identity);
					newImage.sprite = ReadImage2[0];
					newImage.transform.SetParent (clone.transform,false);
					newImage.transform.localScale = new Vector3 (1, 1, 1);
				}
				else if(zoneNum == 2 && UIOfSectionChoose.gm.profile.areaDictionary[areaNum].zoneDictionary[zoneNum].levelDictionary[levelNum].levelState == State.Locked){
           
                    Image newImage = (Image)Instantiate (LockImage, pos [k], Quaternion.identity);
					newImage.sprite = ReadImage2[1];
					newImage.transform.SetParent (clone.transform,false);
					newImage.transform.localScale = new Vector3 (1, 1, 1);
				}
				else if(zoneNum == 3 && UIOfSectionChoose.gm.profile.areaDictionary[areaNum].zoneDictionary[zoneNum].levelDictionary[levelNum].levelState == State.Locked){
            
                    Image newImage = (Image)Instantiate (LockImage, pos [k], Quaternion.identity);
					newImage.sprite = ReadImage2[2];
					newImage.transform.SetParent (clone.transform,false);
					newImage.transform.localScale = new Vector3 (1, 1, 1);
				}

			    if(zoneNum == 1 && UIOfSectionChoose.gm.profile.areaDictionary[areaNum].zoneDictionary[zoneNum].levelDictionary[levelNum].levelState == State.Active){
                   // Debug.Log("Zone1&Active");
                    newButton.image.sprite = ReadImage1[0];
                    FadeIn = newButton.GetComponent<Animator>();
                    FadeIn.enabled = true;
				}
				if(zoneNum == 1 && UIOfSectionChoose.gm.profile.areaDictionary[areaNum].zoneDictionary[zoneNum].levelDictionary[levelNum].levelState == State.Finished){
                    //Debug.Log("Zone1&Finished");
                    newButton.image.sprite = ReadImage1[1];
                    FadeIn = newButton.GetComponent<Animator>();
                    FadeIn.enabled = false;
				}
				if(zoneNum == 2 && UIOfSectionChoose.gm.profile.areaDictionary[areaNum].zoneDictionary[zoneNum].levelDictionary[levelNum].levelState == State.Active){
                    //Debug.Log("Zone2&Active");
                    newButton.image.sprite = ReadImage1[0];
                    FadeIn = newButton.GetComponent<Animator>();
                    FadeIn.enabled = true;
				}
				if(zoneNum == 2 && UIOfSectionChoose.gm.profile.areaDictionary[areaNum].zoneDictionary[zoneNum].levelDictionary[levelNum].levelState == State.Finished){
                    Debug.Log("Zone2&Finished"+zoneNum+"L:"+levelNum);
                    newButton.image.sprite = ReadImage1[2];
                    FadeIn = newButton.GetComponent<Animator>();
                    FadeIn.enabled = false;
				}
				if(zoneNum == 3 && UIOfSectionChoose.gm.profile.areaDictionary[areaNum].zoneDictionary[zoneNum].levelDictionary[levelNum].levelState == State.Active){
                   // Debug.Log("Zone3&Active");
                    newButton.image.sprite = ReadImage1[0];
                    FadeIn = newButton.GetComponent<Animator>();
                    FadeIn.enabled = true;
				}
				if(zoneNum == 3 && UIOfSectionChoose.gm.profile.areaDictionary[areaNum].zoneDictionary[zoneNum].levelDictionary[levelNum].levelState == State.Finished){
					newButton.image.sprite = ReadImage1[3];
                    FadeIn = newButton.GetComponent<Animator>();
                    FadeIn.enabled = false;
				}
                Text newText = (Text)Instantiate(LevelText, pos1[k], Quaternion.identity);  
                newText.transform.SetParent(clone.transform, false);
                newText.transform.localScale = new Vector3(1, 1, 1);
                newText.text = newButton.name;
               // Debug.Log("ProfileState: " + UIOfSectionChoose.gm.profile.areaDictionary[areaNum].zoneDictionary[zoneNum].levelDictionary[levelNum].levelState);
             //   Debug.Log("ZoneNum: " + zoneNum + "buttonNum  : " + int.Parse(newButton.name) + "State: " + UIOfSectionChoose.gm.profile.areaDictionary[areaNum].zoneDictionary[zoneNum].levelDictionary[levelNum].levelState);
				newButton.onClick.AddListener (() => {
					//				Debug.Log(int.Parse(newButton.name)+"COUNT NAME:(((((((((((((");
                    UIOfSectionChoose.gm.soundstate(SoundState.Level);
                    //SoundManager2D.stopLoopingSound("a111");
					if(int.Parse(newButton.name)<=20){
						zoneNum = 1;
					}
                    else if (int.Parse(newButton.name) > 20 && int.Parse(newButton.name) <= 40)
                    {
						zoneNum = 2;//2
					}
					else if(int.Parse(newButton.name)>40){
						zoneNum = 3;//3
					}
                    UIOfSectionChoose.gm.currentZone = zoneNum;
                    levelNum = ((int.Parse(newButton.name) - 1) % 20) + 1;
                    Debug.Log("LEVEL  NUM: " + levelNum+" Z:"+zoneNum);
                    UIOfSectionChoose.gm.currentLevel = levelNum;
                    //areaNum = UIOfSectionChoose.gm.currentArea;
                    UIOfSectionChoose.gm.word = (TxtToDictionary.mainJson[areaNum - 1][zoneNum - 1][levelNum - 1].ToString()).Replace("\"", string.Empty);
                    Debug.Log("word: "+ UIOfSectionChoose.gm.word);
                    UIOfSectionChoose.gm.hint1 = (TxtToDictionary.hintsJson1[areaNum - 1][zoneNum - 1][levelNum - 1].ToString()).Replace("\"", string.Empty);
                    UIOfSectionChoose.gm.hint2 = (TxtToDictionary.hintsJson2[areaNum - 1][zoneNum - 1][levelNum - 1].ToString()).Replace("\"", string.Empty);
                    UIOfSectionChoose.gm.hint1 = UIOfSectionChoose.gm.hint1.Remove(UIOfSectionChoose.gm.hint1.Length - 2);
                    UIOfSectionChoose.gm.hint2 = UIOfSectionChoose.gm.hint2.Remove(UIOfSectionChoose.gm.hint2.Length - 2);
                    Debug.Log("hint1: " + UIOfSectionChoose.gm.hint1.Remove(UIOfSectionChoose.gm.hint1.Length - 2));
                    Debug.Log("hint2: "+UIOfSectionChoose.gm.hint2);
                    Debug.Log("LOOOOOOOAAAAAAAAAAAAAAAAAAAADDDDDDDDDDDDDDDDDDDDDII"+UIOfSectionChoose.gm.profile.areaDictionary[areaNum].zoneDictionary[zoneNum].levelDictionary[levelNum].levelState);
                    if (UIOfSectionChoose.gm.profile.areaDictionary[areaNum].zoneDictionary[zoneNum].levelDictionary[levelNum].levelState != State.Locked)
                    {
                        Debug.Log("LOOOOOOOAAAAAAAAAAAAAAAAAAAADDDDDDDDDDDDDDDDDDDDDIIIIIIIIIIIIIIIIIINNNNNNNNNNNGGGGGGGGGGG");
                        UIOfSectionChoose.gm.currentGameState = GameState.Game;
                        SceneManager.LoadSceneAsync("Game");
					}
				});
			}
			
		}
		
	}
	
	/*public GameObject NextObject(){
		
		foreach (GameObject instance in poolInstances) {
			if(instance.activeSelf != true){
                Debug.Log("instance.activeSelf != true");
				return instance;
			}
		}
        Debug.Log("CreateInstance");
		return CreateInstance ();
	}*/
	
	
	
	private GameObject CreateInstance(){
		var clone =  Instantiate (instances) as GameObject; //clonesazi
		poolInstances.Add (clone); //add object to pool
		return clone;
	}
    public void back()
    {
        LevelSelection.SetActive(false);
        SectionChoose.SetActive(true);
        UIOfSectionChoose.gm.currentGameState = GameState.SectionMenu;
        SceneManager.LoadSceneAsync("MainMenu");
    }
}

