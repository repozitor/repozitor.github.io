﻿using UnityEngine;
using System.Collections;

public class EndGameAnimation : MonoBehaviour {

	//some flags to check when certain animations are playing
	//animation states - the values in the animator conditions

    Animator animator;

    const int STATE_first = 0;
	const int STATE_gameOver1 = 1;
    const int STATE_gameOver2 = 2;
    const int STATE_gameOver3 = 3;
	const int STATE_win1 = 4;
    const int STATE_win2 = 5;
    const int STATE_win3 = 6;
	
	int currentAnimationState = STATE_first;
    int zoneNum = UIOfSectionChoose.gm.currentZone;

         // Use this for initialization
	void Start()
	{

		//define the animator attached to the player
		
        animator = this.GetComponent<Animator>();
		animator.SetInteger ("state", STATE_first);
        chooseState();
	}
	
	    // FixedUpdate is used insead of Update to better handle the physics based jump
	void FixedUpdate()
    {  }

        // Change the players animation state
    void chooseState()
    {
        if (UIOfSectionChoose.gm.currentGameState == GameState.Loose)
        {
            switch (zoneNum)
            {
                case 1:{
                        changeState(STATE_gameOver1);
                        break;}
                case 2:{
                        changeState(STATE_gameOver2);
                        break;}
                case 3:{
                        changeState(STATE_gameOver3);
                        break;}
            }
        }
        if (UIOfSectionChoose.gm.currentGameState == GameState.Win)
        {
            Debug.Log("win");
            switch (zoneNum)
            {
                case 1:{
                        changeState(STATE_win1);
                        break;}
                case 2:{
                        changeState(STATE_win2);
                        break;}
                case 3:{
                        changeState(STATE_win3);
                        break;}
            }
        }
    }
          
	 
    // Change the players animation state
    void changeState(int state){
		if (currentAnimationState == state)
			return;
		switch (state) {

            case STATE_first:
            {
                 animator.SetInteger("state", STATE_gameOver1);
                 break;}
            case STATE_gameOver1:
			{
                animator.SetInteger("state", STATE_gameOver1);
				break;}
            case STATE_gameOver2:
			{
                animator.SetInteger("state", STATE_gameOver2);
				break;}
            case STATE_gameOver3:
			{
                animator.SetInteger("state", STATE_gameOver3);
				break;}
            case STATE_win1:
            {
                animator.SetInteger("state", STATE_win1);
                break;
            }
            case STATE_win2:
            {
                animator.SetInteger("state", STATE_win2);
                break;
            }
            case STATE_win3:
            {
                animator.SetInteger("state", STATE_win3);
                break;
            }
           
		}
		currentAnimationState = state;
	}

}
