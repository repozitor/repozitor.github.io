using UnityEngine;
using System.Collections;

public class PlayerController : MonoBehaviour {
	Animator animator;

	//some flags to check when certain animations are playing
	Animation anim;
	//animation states - the values in the animator conditions
	const int STATE_first = 0;
	const int STATE_robin = 1;
	const int STATE_owl = 2;
	const int STATE_turtle = 3;
	const int STATE_littleJohn = 4;
	
	int currentAnimationState = STATE_first;
	int randomSeeds;
	// Use this for initialization
	void Start()
	{
		anim = GetComponent<Animation>();

		//define the animator attached to the player
		animator = this.GetComponent<Animator>();
		randomAnimation ();
		//animator.SetInteger ("state", STATE_first);
	}
	
	// FixedUpdate is used insead of Update to better handle the physics based jump
	void FixedUpdate()
	{

	}
	//--------------------------------------
	// Change the players animation state
	//--------------------------------------
	void randomAnimation(){
		randomSeeds = (int)((System.DateTime.Now.Ticks)%1000);
		Random.seed = randomSeeds;
		int randomNumber = (int)Random.Range (1f, 4.99f);
		Debug.Log (randomNumber);
		changeState (randomNumber);
	}
	void changeState(int state){
		if (currentAnimationState == state)
			return;
		switch (state) {
			
		case STATE_robin:
			{
				animator.SetInteger ("state", STATE_robin);
				break;}
		case STATE_littleJohn:
			{
				animator.SetInteger ("state", STATE_littleJohn);
				break;}
		case STATE_turtle:
			{
				animator.SetInteger ("state", STATE_turtle);
				break;}
		case STATE_owl:
			{
				animator.SetInteger ("state", STATE_owl);
				break;}
		}
		currentAnimationState = state;
	}

}
